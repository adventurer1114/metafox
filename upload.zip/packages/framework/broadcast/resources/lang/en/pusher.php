<?php

/* this is auto generated file */
return [
    'app_id_label'  => 'Pusher App ID',
    'cluster_label' => 'Pusher Cluster',
    'host_label'    => 'Pusher Host',
    'key_label'     => 'Pusher Key',
    'secret_label'  => 'Pusher Secret',
];
