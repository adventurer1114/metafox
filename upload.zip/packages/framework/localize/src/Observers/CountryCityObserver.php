<?php

namespace MetaFox\Localize\Observers;

/**
 * Class CountryCityObserver.
 */
class CountryCityObserver
{
}
