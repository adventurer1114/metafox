<?php

/* this is auto generated file */
return [
    'diff_from_gtm' => 'GMT Offset',
    'name'          => 'Timezone',
    'offset'        => 'Offset',
];
