<?php

/* this is auto generated file */
return [
    'can_not_action_on_default_currency'   => 'Can not action on default currency.',
    'currency_deleted_successfully'        => 'Currency has been deleted successfully.',
    'currency_successfully_activated'      => 'Currency successfully activated.',
    'currency_successfully_created'        => 'Currency successfully created.',
    'currency_successfully_deactived'      => 'Currency successfully deactivated.',
    'currency_successfully_set_as_default' => 'Currency successfully set as default.',
    'currency_successfully_updated'        => 'Currency successfully updated.',
    'language_successfully_activated'      => 'Language successfully activated.',
    'language_successfully_deactivated'    => 'Language successfully deactivated.',
    'please_choose_default_locale'         => 'Please choose default locale.',
    'timezone_successfully_activated'      => 'Timezone successfully activated.',
    'timezone_successfully_deactived'      => 'Timezone successfully deactivated.',
];
