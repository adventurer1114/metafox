<?php

/* this is auto generated file */
return [
    'edit_language' => 'Edit Language',
];
