<?php

/* this is auto generated file */
return [
    'invalid_format' => 'Invalid format.',
];
