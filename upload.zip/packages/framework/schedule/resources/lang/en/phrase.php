<?php

/* this is auto generated file */
return [
    'job'                    => 'Job',
    'next_due'               => 'Next Due',
    'schedule'               => 'Schedule',
    'schedule_command_guide' => 'Sometimes, shared hosting must be used that does not permit the installation of supervisor to run the queue worker. For Cpanel servers, the Cron statement might look like
:command',
    'schedule_jobs' => 'Schedule Jobs',
    'settings'      => 'Settings',
];
