<?php

/* this is auto generated file */
return [
    [
        'menu'        => 'core.adminSidebarMenu',
        'parent_name' => 'settings',
        'name'        => 'schedule',
        'label'       => 'schedule::phrase.schedule',
        'ordering'    => 0,
        'to'          => '/admincp/schedule/job/browse',
    ],
    [
        'menu'     => 'schedule.admin',
        'name'     => 'jobs',
        'label'    => 'schedule::phrase.schedule_jobs',
        'ordering' => 0,
        'to'       => '/admincp/schedule/job/browse',
    ],
];
