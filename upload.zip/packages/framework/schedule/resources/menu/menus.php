<?php

/* this is auto generated file */
return [
    [
        'name'       => 'schedule.admin',
        'resolution' => 'admin',
        'type'       => 'admin_top',
        'title'      => 'Manage Schedule',
    ],
];
