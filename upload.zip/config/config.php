<?php

/**
 * stub: packages/config/config.stub.
 */

return [

];
