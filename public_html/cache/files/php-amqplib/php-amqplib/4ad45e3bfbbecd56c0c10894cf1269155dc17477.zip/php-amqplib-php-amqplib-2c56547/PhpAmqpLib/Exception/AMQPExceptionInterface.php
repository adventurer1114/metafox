<?php

namespace PhpAmqpLib\Exception;

interface AMQPExceptionInterface
{
}
