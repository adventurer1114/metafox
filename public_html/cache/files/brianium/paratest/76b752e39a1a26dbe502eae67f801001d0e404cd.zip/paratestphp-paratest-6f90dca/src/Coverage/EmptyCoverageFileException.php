<?php

declare(strict_types=1);

namespace ParaTest\Coverage;

use RuntimeException;

/** @internal */
final class EmptyCoverageFileException extends RuntimeException
{
}
