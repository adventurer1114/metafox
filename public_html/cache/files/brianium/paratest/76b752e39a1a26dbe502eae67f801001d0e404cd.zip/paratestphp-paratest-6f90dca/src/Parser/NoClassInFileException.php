<?php

declare(strict_types=1);

namespace ParaTest\Parser;

use Exception;

/** @internal */
final class NoClassInFileException extends Exception
{
}
