<?php

declare(strict_types=1);

namespace ParaTest\Runners\PHPUnit;

use RuntimeException;

/** @internal */
final class EmptyLogFileException extends RuntimeException
{
}
