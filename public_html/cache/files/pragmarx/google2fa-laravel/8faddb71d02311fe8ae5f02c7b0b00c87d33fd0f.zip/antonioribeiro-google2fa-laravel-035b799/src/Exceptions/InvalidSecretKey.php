<?php

namespace PragmaRX\Google2FALaravel\Exceptions;

use Exception;

class InvalidSecretKey extends Exception
{
}
