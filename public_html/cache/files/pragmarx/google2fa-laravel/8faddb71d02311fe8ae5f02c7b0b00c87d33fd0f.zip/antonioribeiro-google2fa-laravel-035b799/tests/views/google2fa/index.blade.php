google2fa view

@foreach ($errors->all() as $message)
    {{ $message }}<br>
@endforeach
