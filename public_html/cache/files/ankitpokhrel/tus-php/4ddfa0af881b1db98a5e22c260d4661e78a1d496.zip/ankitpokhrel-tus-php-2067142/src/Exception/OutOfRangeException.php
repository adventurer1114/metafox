<?php

namespace TusPhp\Exception;

class OutOfRangeException extends \OutOfRangeException
{
}
