<?php

namespace Pheanstalk\Exception;

/**
 * An exception originating as a beanstalkd server error.
 *
 * @author  Paul Annesley
 */
class ServerUnknownCommandException extends ServerException
{
}
