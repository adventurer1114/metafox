<?php


namespace Pheanstalk\Contract;

interface JobIdInterface
{
    public function getId(): int;
}
