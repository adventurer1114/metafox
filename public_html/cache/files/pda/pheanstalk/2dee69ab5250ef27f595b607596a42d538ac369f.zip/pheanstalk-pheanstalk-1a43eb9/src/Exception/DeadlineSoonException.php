<?php


namespace Pheanstalk\Exception;

class DeadlineSoonException extends ClientException
{

}
