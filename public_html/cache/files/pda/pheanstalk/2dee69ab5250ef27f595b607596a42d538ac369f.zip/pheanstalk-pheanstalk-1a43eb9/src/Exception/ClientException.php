<?php

namespace Pheanstalk\Exception;

use Pheanstalk\Exception;

/**
 * An exception originating from the beanstalkd client.
 */
class ClientException extends Exception
{
}
