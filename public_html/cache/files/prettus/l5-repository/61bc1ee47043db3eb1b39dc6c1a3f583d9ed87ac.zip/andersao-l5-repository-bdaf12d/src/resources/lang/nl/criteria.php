<?php
return [
    'fields_not_accepted' => 'Kolommen :field worden niet geaccepteerd in de zoekopdracht'
];
