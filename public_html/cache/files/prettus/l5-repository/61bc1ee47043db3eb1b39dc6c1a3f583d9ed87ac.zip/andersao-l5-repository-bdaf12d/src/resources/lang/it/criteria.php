<?php
return [
    'fields_not_accepted' => 'I campi :field non sono accettati nella ricerca'
];
