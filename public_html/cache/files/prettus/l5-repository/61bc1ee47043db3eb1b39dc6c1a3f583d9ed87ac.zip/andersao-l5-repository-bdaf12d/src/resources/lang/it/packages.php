<?php
return [
    'prettus_laravel_validation_required' => "Pacchetto richiesto. Installa prettus/laravel-validation ('composer require prettus/laravel-validation'), per favore.",
    'league_fractal_required'             => "Pacchetto richiesto. Installa league/fractal ('composer require league/fractal') (0.12.*), per favore."
];
