<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

/**
 * @psalm-immutable
 */
class UnresolvedDivisionOp extends UnresolvedBinaryOp
{
}
