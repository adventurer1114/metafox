<?php

namespace Psalm\Issue;

class CircularReference extends CodeIssue
{
    public const ERROR_LEVEL = 7;
    public const SHORTCODE = 131;
}
