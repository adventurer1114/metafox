<?php

namespace Psalm\Internal\DataFlow;

class TaintSource extends DataFlowNode
{
}
