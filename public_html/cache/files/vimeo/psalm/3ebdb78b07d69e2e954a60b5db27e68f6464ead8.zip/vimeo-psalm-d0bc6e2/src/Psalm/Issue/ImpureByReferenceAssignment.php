<?php

namespace Psalm\Issue;

class ImpureByReferenceAssignment extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 220;
}
