<?php

namespace Psalm\Exception;

use Exception;

class ConfigCreationException extends Exception
{
}
