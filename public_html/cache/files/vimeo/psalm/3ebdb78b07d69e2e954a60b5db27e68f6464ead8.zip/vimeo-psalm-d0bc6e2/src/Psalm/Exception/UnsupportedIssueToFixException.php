<?php

namespace Psalm\Exception;

use Exception;

class UnsupportedIssueToFixException extends Exception
{

}
