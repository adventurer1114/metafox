<?php

namespace Psalm\Exception;

use Exception;

class RefactorException extends Exception
{
}
