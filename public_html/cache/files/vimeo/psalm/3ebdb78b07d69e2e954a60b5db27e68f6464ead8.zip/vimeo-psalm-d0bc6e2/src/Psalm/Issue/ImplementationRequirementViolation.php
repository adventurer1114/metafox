<?php

namespace Psalm\Issue;

class ImplementationRequirementViolation extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 240;
}
