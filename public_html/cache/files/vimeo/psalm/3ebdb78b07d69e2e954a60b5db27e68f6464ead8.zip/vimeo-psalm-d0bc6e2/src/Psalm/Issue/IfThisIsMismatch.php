<?php

namespace Psalm\Issue;

class IfThisIsMismatch extends CodeIssue
{
    public const ERROR_LEVEL = 4;
    public const SHORTCODE = 300;
}
