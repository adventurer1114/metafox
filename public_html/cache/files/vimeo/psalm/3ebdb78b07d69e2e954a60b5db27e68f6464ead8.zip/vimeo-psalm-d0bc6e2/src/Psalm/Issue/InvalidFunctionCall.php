<?php

namespace Psalm\Issue;

class InvalidFunctionCall extends CodeIssue
{
    public const ERROR_LEVEL = 6;
    public const SHORTCODE = 64;
}
