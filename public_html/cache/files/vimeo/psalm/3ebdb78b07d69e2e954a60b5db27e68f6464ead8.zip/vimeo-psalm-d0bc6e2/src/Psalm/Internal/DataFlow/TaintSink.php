<?php

namespace Psalm\Internal\DataFlow;

class TaintSink extends DataFlowNode
{
}
