<?php

namespace Psalm\Exception;

use Exception;

class FileIncludeException extends Exception
{
}
