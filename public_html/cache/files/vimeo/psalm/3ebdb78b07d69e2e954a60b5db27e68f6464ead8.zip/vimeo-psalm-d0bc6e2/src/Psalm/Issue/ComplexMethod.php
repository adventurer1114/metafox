<?php

namespace Psalm\Issue;

class ComplexMethod extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 260;
}
