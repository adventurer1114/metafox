<?php

namespace Psalm\Issue;

class DuplicateParam extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 65;
}
