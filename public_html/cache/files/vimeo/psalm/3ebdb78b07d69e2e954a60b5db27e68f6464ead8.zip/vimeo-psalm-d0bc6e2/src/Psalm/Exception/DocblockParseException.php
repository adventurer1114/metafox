<?php

namespace Psalm\Exception;

use Exception;

class DocblockParseException extends Exception
{
}
