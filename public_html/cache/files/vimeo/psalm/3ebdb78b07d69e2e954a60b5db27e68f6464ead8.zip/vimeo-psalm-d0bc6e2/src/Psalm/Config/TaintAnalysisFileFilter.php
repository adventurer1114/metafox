<?php

namespace Psalm\Config;

class TaintAnalysisFileFilter extends FileFilter
{
}
