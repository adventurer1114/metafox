<?php

namespace Psalm\Issue;

class DuplicateConstant extends ClassIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 302;
}
