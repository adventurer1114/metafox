<?php

namespace Psalm\Exception;

use Exception;

class UnanalyzedFileException extends Exception
{
}
