<?php

namespace Psalm\Issue;

class ImpurePropertyAssignment extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 204;
}
