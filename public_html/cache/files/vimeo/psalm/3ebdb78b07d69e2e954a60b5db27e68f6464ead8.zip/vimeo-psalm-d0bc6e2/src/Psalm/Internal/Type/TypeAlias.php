<?php

namespace Psalm\Internal\Type;

interface TypeAlias
{
}
