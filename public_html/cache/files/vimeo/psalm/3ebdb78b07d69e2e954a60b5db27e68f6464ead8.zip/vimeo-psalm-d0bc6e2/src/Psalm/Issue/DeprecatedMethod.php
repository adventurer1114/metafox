<?php

namespace Psalm\Issue;

class DeprecatedMethod extends MethodIssue
{
    public const ERROR_LEVEL = 2;
    public const SHORTCODE = 1;
}
