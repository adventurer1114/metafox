<?php

namespace Psalm\Exception;

use Exception;

class InvalidClasslikeOverrideException extends Exception
{
}
