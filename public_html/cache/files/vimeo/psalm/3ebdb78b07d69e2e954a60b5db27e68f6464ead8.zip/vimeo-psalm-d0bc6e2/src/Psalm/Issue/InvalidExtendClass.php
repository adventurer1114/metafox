<?php

namespace Psalm\Issue;

class InvalidExtendClass extends ClassIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 232;
}
