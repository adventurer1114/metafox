<?php

namespace Psalm\Issue;

class InterfaceInstantiation extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 158;
}
