<?php

namespace Psalm\Issue;

class InvalidEnumBackingType extends ClassIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 276;
}
