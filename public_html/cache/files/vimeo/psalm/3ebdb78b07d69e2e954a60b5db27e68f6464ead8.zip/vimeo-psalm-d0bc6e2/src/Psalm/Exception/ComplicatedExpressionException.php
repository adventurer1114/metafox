<?php

namespace Psalm\Exception;

use Exception;

class ComplicatedExpressionException extends Exception
{
}
