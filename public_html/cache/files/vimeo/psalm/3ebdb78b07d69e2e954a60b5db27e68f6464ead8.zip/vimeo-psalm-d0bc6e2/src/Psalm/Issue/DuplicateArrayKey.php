<?php

namespace Psalm\Issue;

class DuplicateArrayKey extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 151;
}
