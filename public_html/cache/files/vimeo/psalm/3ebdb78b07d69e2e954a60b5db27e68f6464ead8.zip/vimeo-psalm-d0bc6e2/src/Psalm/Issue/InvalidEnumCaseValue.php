<?php

namespace Psalm\Issue;

class InvalidEnumCaseValue extends ClassIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 278;
}
