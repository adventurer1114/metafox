<?php

namespace Psalm\Exception;

class IncorrectDocblockException extends DocblockParseException
{
}
