<?php

namespace Psalm\Issue;

class DeprecatedFunction extends FunctionIssue
{
    public const ERROR_LEVEL = 2;
    public const SHORTCODE = 201;
}
