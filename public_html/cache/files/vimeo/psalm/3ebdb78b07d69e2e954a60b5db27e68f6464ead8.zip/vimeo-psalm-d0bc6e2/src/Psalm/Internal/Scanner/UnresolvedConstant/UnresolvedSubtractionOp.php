<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

/**
 * @psalm-immutable
 */
class UnresolvedSubtractionOp extends UnresolvedBinaryOp
{
}
