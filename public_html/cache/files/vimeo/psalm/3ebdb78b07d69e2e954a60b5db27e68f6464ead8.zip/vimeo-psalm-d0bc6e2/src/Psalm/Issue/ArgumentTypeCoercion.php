<?php

namespace Psalm\Issue;

class ArgumentTypeCoercion extends ArgumentIssue
{
    public const ERROR_LEVEL = 3;
    public const SHORTCODE = 193;
}
