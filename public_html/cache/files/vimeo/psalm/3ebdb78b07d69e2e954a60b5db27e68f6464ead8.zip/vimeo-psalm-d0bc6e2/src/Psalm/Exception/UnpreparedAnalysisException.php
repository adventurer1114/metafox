<?php

namespace Psalm\Exception;

use Exception;

class UnpreparedAnalysisException extends Exception
{
}
