<?php

namespace Psalm\Exception;

class ConfigNotFoundException extends ConfigException
{
}
