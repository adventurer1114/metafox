<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

/**
 * @psalm-immutable
 */
class UnresolvedBitwiseAnd extends UnresolvedBinaryOp
{
}
