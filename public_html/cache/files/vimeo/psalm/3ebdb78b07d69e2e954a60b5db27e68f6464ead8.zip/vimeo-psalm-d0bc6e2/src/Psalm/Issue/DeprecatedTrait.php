<?php

namespace Psalm\Issue;

class DeprecatedTrait extends CodeIssue
{
    public const ERROR_LEVEL = 2;
    public const SHORTCODE = 171;
}
