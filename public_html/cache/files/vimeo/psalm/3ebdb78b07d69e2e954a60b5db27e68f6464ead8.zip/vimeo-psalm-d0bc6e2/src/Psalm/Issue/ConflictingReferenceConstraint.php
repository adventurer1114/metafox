<?php

namespace Psalm\Issue;

class ConflictingReferenceConstraint extends CodeIssue
{
    public const ERROR_LEVEL = 7;
    public const SHORTCODE = 85;
}
