<?php

namespace Psalm\Issue;

class ExtensionRequirementViolation extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 239;
}
