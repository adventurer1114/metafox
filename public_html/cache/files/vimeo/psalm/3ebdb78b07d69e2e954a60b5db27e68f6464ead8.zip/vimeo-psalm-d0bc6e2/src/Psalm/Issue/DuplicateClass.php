<?php

namespace Psalm\Issue;

class DuplicateClass extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 71;
}
