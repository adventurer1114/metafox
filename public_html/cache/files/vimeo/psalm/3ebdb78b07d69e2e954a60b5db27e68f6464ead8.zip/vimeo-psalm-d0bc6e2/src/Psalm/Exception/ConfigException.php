<?php

namespace Psalm\Exception;

use Exception;

class ConfigException extends Exception
{
}
