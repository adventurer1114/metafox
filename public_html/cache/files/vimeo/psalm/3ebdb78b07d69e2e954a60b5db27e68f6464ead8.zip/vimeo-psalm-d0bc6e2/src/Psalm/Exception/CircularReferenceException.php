<?php

namespace Psalm\Exception;

use Exception;

class CircularReferenceException extends Exception
{
}
