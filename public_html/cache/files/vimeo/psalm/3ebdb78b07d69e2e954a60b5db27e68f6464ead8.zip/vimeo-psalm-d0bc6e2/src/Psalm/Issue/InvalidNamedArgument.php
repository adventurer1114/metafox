<?php

namespace Psalm\Issue;

class InvalidNamedArgument extends ArgumentIssue
{
    public const ERROR_LEVEL = 6;
    public const SHORTCODE = 238;
}
