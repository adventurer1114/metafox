<?php

namespace Psalm\Exception;

use Exception;

class InvalidMethodOverrideException extends Exception
{
}
