<?php

namespace Psalm\Issue;

class InvalidArrayOffset extends CodeIssue
{
    public const ERROR_LEVEL = 6;
    public const SHORTCODE = 115;
}
