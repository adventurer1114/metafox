<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

/**
 * @psalm-immutable
 */
class UnresolvedAdditionOp extends UnresolvedBinaryOp
{
}
