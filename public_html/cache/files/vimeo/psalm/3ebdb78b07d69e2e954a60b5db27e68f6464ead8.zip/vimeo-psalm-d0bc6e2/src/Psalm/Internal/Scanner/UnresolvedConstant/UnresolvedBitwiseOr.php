<?php

namespace Psalm\Internal\Scanner\UnresolvedConstant;

/**
 * @psalm-immutable
 */
class UnresolvedBitwiseOr extends UnresolvedBinaryOp
{
}
