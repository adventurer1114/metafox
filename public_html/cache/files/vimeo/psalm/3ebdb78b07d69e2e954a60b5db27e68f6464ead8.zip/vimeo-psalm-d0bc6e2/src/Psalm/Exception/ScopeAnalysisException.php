<?php

namespace Psalm\Exception;

use Exception;

class ScopeAnalysisException extends Exception
{
}
