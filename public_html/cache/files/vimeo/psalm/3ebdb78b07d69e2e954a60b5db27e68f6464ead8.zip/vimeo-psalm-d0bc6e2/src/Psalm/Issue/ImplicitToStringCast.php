<?php

namespace Psalm\Issue;

class ImplicitToStringCast extends CodeIssue
{
    public const ERROR_LEVEL = 4;
    public const SHORTCODE = 60;
}
