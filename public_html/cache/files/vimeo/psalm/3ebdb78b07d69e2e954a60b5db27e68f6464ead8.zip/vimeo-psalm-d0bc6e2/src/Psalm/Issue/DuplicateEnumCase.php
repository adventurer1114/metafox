<?php

namespace Psalm\Issue;

class DuplicateEnumCase extends ClassIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 277;
}
