<?php

namespace Psalm\Issue;

class AssignmentToVoid extends CodeIssue
{
    public const ERROR_LEVEL = 7;
    public const SHORTCODE = 121;
}
