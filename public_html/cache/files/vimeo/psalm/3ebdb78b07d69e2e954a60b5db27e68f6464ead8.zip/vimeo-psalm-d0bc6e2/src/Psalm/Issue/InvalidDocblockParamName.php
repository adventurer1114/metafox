<?php

namespace Psalm\Issue;

class InvalidDocblockParamName extends CodeIssue
{
    public const ERROR_LEVEL = 2;
    public const SHORTCODE = 187;
}
