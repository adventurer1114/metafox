<?php

namespace Psalm\Issue;

class InternalProperty extends PropertyIssue
{
    public const ERROR_LEVEL = 4;
    public const SHORTCODE = 176;
}
