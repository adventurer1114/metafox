<?php

namespace Psalm\Issue;

class DuplicateFunction extends CodeIssue
{
    public const ERROR_LEVEL = -1;
    public const SHORTCODE = 180;
}
