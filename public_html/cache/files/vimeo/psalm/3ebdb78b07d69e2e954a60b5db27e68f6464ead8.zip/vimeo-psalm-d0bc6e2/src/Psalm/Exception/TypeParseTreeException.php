<?php

namespace Psalm\Exception;

use Exception;

class TypeParseTreeException extends Exception
{
}
