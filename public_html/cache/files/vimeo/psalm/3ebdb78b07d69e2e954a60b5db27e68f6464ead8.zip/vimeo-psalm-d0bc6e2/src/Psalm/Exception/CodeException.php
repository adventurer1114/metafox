<?php

namespace Psalm\Exception;

use Exception;

class CodeException extends Exception
{
}
