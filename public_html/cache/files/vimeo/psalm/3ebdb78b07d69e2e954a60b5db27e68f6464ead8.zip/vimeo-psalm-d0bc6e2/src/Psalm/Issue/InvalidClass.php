<?php

namespace Psalm\Issue;

class InvalidClass extends ClassIssue
{
    public const ERROR_LEVEL = 6;
    public const SHORTCODE = 7;
}
