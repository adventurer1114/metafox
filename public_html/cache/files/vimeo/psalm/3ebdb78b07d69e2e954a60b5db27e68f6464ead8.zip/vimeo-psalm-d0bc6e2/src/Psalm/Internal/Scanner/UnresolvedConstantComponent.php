<?php

namespace Psalm\Internal\Scanner;

/**
 * @psalm-immutable
 */
abstract class UnresolvedConstantComponent
{
}
