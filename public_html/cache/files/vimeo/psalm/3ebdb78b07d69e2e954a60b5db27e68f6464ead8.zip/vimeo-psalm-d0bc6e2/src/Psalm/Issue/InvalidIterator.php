<?php

namespace Psalm\Issue;

class InvalidIterator extends CodeIssue
{
    public const ERROR_LEVEL = 6;
    public const SHORTCODE = 9;
}
