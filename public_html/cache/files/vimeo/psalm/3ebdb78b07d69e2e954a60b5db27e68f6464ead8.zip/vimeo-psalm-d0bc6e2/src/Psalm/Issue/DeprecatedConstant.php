<?php

namespace Psalm\Issue;

class DeprecatedConstant extends CodeIssue
{
    public const ERROR_LEVEL = 2;
    public const SHORTCODE = 170;
}
