<?php

namespace Psalm\Issue;

class DeprecatedClass extends ClassIssue
{
    public const ERROR_LEVEL = 2;
    public const SHORTCODE = 98;
}
