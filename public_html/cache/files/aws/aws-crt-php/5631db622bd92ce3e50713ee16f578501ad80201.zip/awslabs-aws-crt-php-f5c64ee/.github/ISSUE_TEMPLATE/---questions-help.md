---
name: "\U0001F4AC Questions / Help"
about: If you have questions, please check AWS Forums or StackOverflow
title: ''
labels: guidance, needs-triage
assignees: ''

---

Confirm by changing [ ] to [x] below:
- [ ] I've searched for [previous similar issues](https://github.com/awslabs/aws-crt-php/issues) and didn't find any solution

**Platform/OS/Hardware/Device**
What are you running the sdk on?

**Describe the question**


**Logs/output**
If applicable, add logs or error output.

*REMEMBER TO SANITIZE YOUR PERSONAL INFO*

