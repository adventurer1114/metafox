<?php

namespace Gitonomy\Git\Exception;

class LogicException extends \LogicException implements GitExceptionInterface
{
}
