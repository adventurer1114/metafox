<?php

declare(strict_types=1);

namespace Qameta\Allure\Attribute;

interface AttributeInterface
{
}
