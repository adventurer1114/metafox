<?php

declare(strict_types=1);

namespace PHPSTORM_META
{

    override(
        \Qameta\Allure\Annotation\AnnotationTestTrait::getAttributeInstance(0),
        map(['' => '@'])
    );

    override(
        \Qameta\Allure\Annotation\AnnotationTestTrait::getLegacyAttributeInstance(0),
        map(['' => '@'])
    );
}
