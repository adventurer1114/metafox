<?php

namespace Mews\Tests\Captcha;

use PHPUnit\Framework\TestCase;

class CaptchaTest extends TestCase
{
    public function testConstructor()
    {
        $this->assertTrue(true);
    }
}
