# LICENSE


https://www.phpfox.com/license-agreement/