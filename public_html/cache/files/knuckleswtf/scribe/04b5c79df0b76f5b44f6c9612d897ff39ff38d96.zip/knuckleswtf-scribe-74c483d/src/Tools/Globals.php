<?php

namespace Knuckles\Scribe\Tools;

class Globals
{
    public const SCRIBE_VERSION = '3.37.2';

    public static bool $shouldBeVerbose = false;

    public static $__beforeResponseCall;

    public static $__afterGenerating;

    public static $__instantiateFormRequestUsing;
}
