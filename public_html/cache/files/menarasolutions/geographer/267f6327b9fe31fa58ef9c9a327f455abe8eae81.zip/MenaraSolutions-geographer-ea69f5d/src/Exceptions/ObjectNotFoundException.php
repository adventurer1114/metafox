<?php

namespace MenaraSolutions\Geographer\Exceptions;

/**
 * Class ObjectNotFoundException
 * @package MenaraSolutions\Geographer\Exceptions
 */
class ObjectNotFoundException extends \Exception 
{
    
}