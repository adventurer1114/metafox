<?php

namespace MenaraSolutions\Geographer\Exceptions;

/**
 * Class MisconfigurationException
 * @package MenaraSolutions\FluentGeonames\Exceptions
 */
class MisconfigurationException extends \Exception
{
}