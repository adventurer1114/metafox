<?php

namespace MenaraSolutions\Geographer\Exceptions;

/**
 * Class UnknownFieldException
 * @package MenaraSolutions\FluentGeonames\Exceptions
 */
class UnknownFieldException extends \Exception
{

}