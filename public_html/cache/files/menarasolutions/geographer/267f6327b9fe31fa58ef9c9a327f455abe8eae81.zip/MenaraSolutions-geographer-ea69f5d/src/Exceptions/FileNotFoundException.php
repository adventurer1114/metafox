<?php

namespace MenaraSolutions\Geographer\Exceptions;

/**
 * Class FileNotFoundException
 * @package MenaraSolutions\FluentGeonames\Exceptions
 */
class FileNotFoundException extends \Exception
{

}