# geographer-data
Basic data package for Geographer - countries and their subdivisions

## Overview

This repository is a set of JSON files that contain country and subdivisions data for [Geographer library](https://github.com/MenaraSolutions/geographer) . It's not tied
to any specific language and may be used by different SDKs or applications.

Feel free to submit fixes and additions directly to this repo.
