---
name: Feature request
about: Suggest an idea for LdapRecord-Laravel
title: "[Feature]"
labels: enhancement
assignees: ''

---

**Describe the feature you'd like:**
