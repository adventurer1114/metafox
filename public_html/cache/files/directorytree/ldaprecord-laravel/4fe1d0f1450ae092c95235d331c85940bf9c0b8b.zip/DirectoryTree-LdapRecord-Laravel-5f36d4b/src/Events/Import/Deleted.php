<?php

namespace LdapRecord\Laravel\Events\Import;

class Deleted extends Event
{
    //
}
