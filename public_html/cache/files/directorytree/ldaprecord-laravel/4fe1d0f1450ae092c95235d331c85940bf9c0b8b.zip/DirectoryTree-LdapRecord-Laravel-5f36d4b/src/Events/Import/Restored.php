<?php

namespace LdapRecord\Laravel\Events\Import;

class Restored extends Event
{
    //
}
