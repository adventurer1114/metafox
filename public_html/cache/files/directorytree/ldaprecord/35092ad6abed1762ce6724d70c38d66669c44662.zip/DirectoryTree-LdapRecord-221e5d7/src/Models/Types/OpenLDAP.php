<?php

namespace LdapRecord\Models\Types;

interface OpenLDAP extends TypeInterface
{
    //
}
