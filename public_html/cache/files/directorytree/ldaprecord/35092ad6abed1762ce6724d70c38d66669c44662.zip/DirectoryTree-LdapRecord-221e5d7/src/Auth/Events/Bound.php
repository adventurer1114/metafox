<?php

namespace LdapRecord\Auth\Events;

class Bound extends Event
{
    //
}
