<?php

namespace LdapRecord\Models\Events;

class Renamed extends Event
{
    //
}
