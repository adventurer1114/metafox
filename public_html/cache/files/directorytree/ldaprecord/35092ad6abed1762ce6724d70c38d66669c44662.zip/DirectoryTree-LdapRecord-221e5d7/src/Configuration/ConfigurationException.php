<?php

namespace LdapRecord\Configuration;

use LdapRecord\LdapRecordException;

class ConfigurationException extends LdapRecordException
{
    //
}
