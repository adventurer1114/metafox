<?php

namespace LdapRecord\Auth\Events;

class Attempting extends Event
{
    //
}
