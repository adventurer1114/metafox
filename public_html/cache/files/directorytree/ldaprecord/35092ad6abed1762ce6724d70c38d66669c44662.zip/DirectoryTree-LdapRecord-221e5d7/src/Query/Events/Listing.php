<?php

namespace LdapRecord\Query\Events;

class Listing extends QueryExecuted
{
    //
}
