<?php

namespace LdapRecord\Query\Events;

class Chunk extends QueryExecuted
{
    //
}
