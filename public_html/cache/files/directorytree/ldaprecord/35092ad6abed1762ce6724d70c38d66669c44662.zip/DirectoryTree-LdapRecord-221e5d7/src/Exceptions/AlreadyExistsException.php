<?php

namespace LdapRecord\Exceptions;

use LdapRecord\LdapRecordException;

class AlreadyExistsException extends LdapRecordException
{
    //
}
