<?php

namespace LdapRecord\Auth\Events;

class Binding extends Event
{
    //
}
