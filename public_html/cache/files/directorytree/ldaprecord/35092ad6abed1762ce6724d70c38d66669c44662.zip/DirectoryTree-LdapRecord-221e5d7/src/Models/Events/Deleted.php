<?php

namespace LdapRecord\Models\Events;

class Deleted extends Event
{
    //
}
