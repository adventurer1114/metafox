<?php

namespace LdapRecord\Query\Events;

class Search extends QueryExecuted
{
    //
}
