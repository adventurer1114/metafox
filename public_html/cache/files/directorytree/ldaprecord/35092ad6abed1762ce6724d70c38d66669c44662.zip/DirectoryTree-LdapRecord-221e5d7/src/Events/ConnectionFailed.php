<?php

namespace LdapRecord\Events;

class ConnectionFailed extends ConnectionEvent
{
    //
}
