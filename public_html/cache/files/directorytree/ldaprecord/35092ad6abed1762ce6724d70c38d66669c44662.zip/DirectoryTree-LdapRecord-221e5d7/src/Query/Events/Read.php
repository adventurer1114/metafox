<?php

namespace LdapRecord\Query\Events;

class Read extends QueryExecuted
{
    //
}
