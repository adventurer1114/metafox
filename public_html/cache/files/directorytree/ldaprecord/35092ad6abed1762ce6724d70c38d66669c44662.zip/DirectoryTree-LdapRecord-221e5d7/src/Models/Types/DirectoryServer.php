<?php

namespace LdapRecord\Models\Types;

interface DirectoryServer extends TypeInterface
{
    //
}
