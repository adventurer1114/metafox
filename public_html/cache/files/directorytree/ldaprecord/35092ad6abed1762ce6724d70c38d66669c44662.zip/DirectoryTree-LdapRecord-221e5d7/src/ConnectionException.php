<?php

namespace LdapRecord;

class ConnectionException extends LdapRecordException
{
    //
}
