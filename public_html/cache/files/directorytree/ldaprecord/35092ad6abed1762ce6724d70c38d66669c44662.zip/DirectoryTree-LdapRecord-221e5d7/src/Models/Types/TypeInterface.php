<?php

namespace LdapRecord\Models\Types;

interface TypeInterface
{
    //
}
