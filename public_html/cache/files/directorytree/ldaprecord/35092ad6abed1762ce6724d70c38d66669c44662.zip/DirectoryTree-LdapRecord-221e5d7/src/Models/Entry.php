<?php

namespace LdapRecord\Models;

class Entry extends Model
{
    //
}
