<?php

namespace LdapRecord\Models;

use LdapRecord\Query\ObjectNotFoundException;

class ModelNotFoundException extends ObjectNotFoundException
{
    //
}
