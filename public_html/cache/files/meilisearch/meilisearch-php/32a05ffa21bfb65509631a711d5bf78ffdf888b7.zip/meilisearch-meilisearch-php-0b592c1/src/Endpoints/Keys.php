<?php

declare(strict_types=1);

namespace MeiliSearch\Endpoints;

use MeiliSearch\Contracts\Endpoint;

class Keys extends Endpoint
{
    protected const PATH = '/keys';
}
